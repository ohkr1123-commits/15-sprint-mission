package com.sprint.mission.discodeit.service.basic;

import com.sprint.mission.discodeit.dto.BinaryContentRequest.BinaryContentCreateRequest;
import com.sprint.mission.discodeit.dto.MessageDto.MessageCreateRequest;
import com.sprint.mission.discodeit.dto.MessageDto.MessageUpdateRequest;
import com.sprint.mission.discodeit.entity.Message;
import com.sprint.mission.discodeit.repository.ChannelRepository;
import com.sprint.mission.discodeit.repository.MessageRepository;
import com.sprint.mission.discodeit.repository.UserRepository;
import com.sprint.mission.discodeit.service.MessageService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class BasicMessageService implements MessageService {

    private final MessageRepository messageRepository;
    private final ChannelRepository channelRepository;
    private final UserRepository userRepository;

    @Override
    public Message create(
            MessageCreateRequest request,
            List<BinaryContentCreateRequest> attachments
    ) {

        if (!channelRepository.existsById(request.channelId())) {
            return null;
        }

        if (!userRepository.existsById(request.authorId())) {
            return null;
        }

        Message message = new Message(
                request.channelId(),
                request.authorId(),
                request.content()
        );

        messageRepository.save(message);

        return message;
    }

    @Override
    public Message read(UUID id) {

        return messageRepository.findById(id).orElse(null);
    }

    // 특정 채널의 메시지만 조회
    @Override
    public List<Message> findAllByChannelId(UUID channelId) {
        return messageRepository.findAllByChannelId(channelId);
    }

    // DTO를 이용한 수정
    @Override
    public Message update(UUID id, MessageUpdateRequest request) {

        Message message = messageRepository.findById(id).orElse(null);

        if (message == null) {
            return null;
        }

        message.setContent(request.content());

        messageRepository.save(message);

        return message;
    }

    @Override
    public void delete(UUID id) {

        messageRepository.deleteById(id);
    }
}